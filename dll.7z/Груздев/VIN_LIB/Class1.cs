﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VIN_LIB
{
    public class Class1
    {
        public static Boolean CheckVIN(String vin)
        {
            if (vin.Length == 17)
            {
                char[] notAllowedSyblos = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
                string str = new string(notAllowedSyblos);
                int count = 0;
                for (int j = 0; j < vin.Length; j++)
                {
                    for (int i = 0; i < str.Length; i++)
                    {
                        String number = Convert.ToString(vin[j]);
                        if (number.ToLower().Contains(str[i]))
                        {
                            count++;
                        }
                    }
                }

                if (count == vin.Length && count == 17)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public static int GetTransportYear(String vin)
        {
            if (vin.Length == 17)
            {
                char[] yearAllow = { 'y', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'r', 's', 't', 'v', 'w', 'x' };
                int[] yearCount = { 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029 };
                String year = Convert.ToString(vin[9]);
                string str = new string(yearAllow);
                int yearName = 0;
                for (int i = 0; i < str.Length; i++)
                {
                    if (year.ToLower().Contains(str[i]))
                    {
                        yearName = yearCount[i];
                    }
                }
                return yearName;
            }
            else
            {
                return 0;
            }
            
        }


        public static String GetVINCountry(String vin)
        {
            if (vin.Length == 17)
            {
                char[] africa = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
                char[] azia = { 'j', 'k', 'l', 'm', 'n', 'p', 'r' };
                char[] europe = { 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
                char[] northAmer = { '1', '2', '3', '4', '5' };
                char[] ocean = { '6', '7' };
                char[] southAmer = { '8', '9' };
                String year = Convert.ToString(vin[0]);
                string strAfrica = new string(africa);
                string strAzia = new string(azia);
                string strEurope = new string(europe);
                string strNorth = new string(northAmer);
                string strOcean = new string(ocean);
                string strSouth = new string(southAmer);
                for (int i = 0; i < strAfrica.Length; i++)
                {
                    if (year.ToLower().Contains(strAfrica[i]))
                    {
                        return "Африка";
                    }
                    else
                    {
                        for (int j = 0; j < strAzia.Length; j++)
                        {
                            if (year.ToLower().Contains(strAzia[j]))
                            {
                                return "Азия";
                            }
                            else
                            {
                                for (int a = 0; a < strEurope.Length; a++)
                                {
                                    if (year.ToLower().Contains(strEurope[a]))
                                    {
                                        return "Европа";
                                    }
                                    else
                                    {
                                        for (int b = 0; b < strNorth.Length; b++)
                                        {
                                            if (year.ToLower().Contains(strNorth[b]))
                                            {
                                                return "Северная Америка";
                                            }
                                            else
                                            {
                                                for (int c = 0; c < strOcean.Length; c++)
                                                {
                                                    if (year.ToLower().Contains(strOcean[c]))
                                                    {
                                                        return "Океания";
                                                    }
                                                    else
                                                    {
                                                        for (int d = 0; d < strSouth.Length; d++)
                                                        {
                                                            if (year.ToLower().Contains(strSouth[d]))
                                                            {
                                                                return "Южная америка";
                                                            }
                                                            else
                                                            {
                                                                ;
                                                            }
                                                        }

                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                return "Ошибка VIN";
            }
            return "Ошибка VIN";
        }
    }
}
