﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VIN_LIB;
using REG_MARK_LIB;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String str = Convert.ToString(Console.ReadLine());
            String mark = Convert.ToString(Console.ReadLine());
            bool checkVIN = VIN_LIB.Class1.CheckVIN(str);
            bool checkMark = REG_MARK_LIB.Class1.CheckMark(mark);
            if (checkVIN == false)
            {
                Console.WriteLine("Вин неверный");
            }
            else
            {
                Console.WriteLine("Вин верный");
            }
            if (checkMark == false)
            {
                Console.WriteLine("Номер неверный");
            }
            else
            {
                Console.WriteLine("Номер верный");
            }
            Console.WriteLine($"Модельный год: {VIN_LIB.Class1.GetTransportYear(str)}");
            Console.WriteLine($"Континент: {VIN_LIB.Class1.GetVINCountry(str)}");
            Console.ReadKey();
        }
    }
}
