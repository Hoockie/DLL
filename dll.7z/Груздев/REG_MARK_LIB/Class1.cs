﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace REG_MARK_LIB
{
    public class Class1
    {
        public static Boolean CheckMark(String mark)
        {
            if (Regex.IsMatch($"{mark.ToLower()}", @"^[a-z]{1}\d{3}[a-z]{2}\d{3}$"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
